#!/usr/bin/env python
# coding: utf-8

# In[4]:


#导入包
import requests
from bs4 import BeautifulSoup
import csv
from tqdm import tqdm#在电脑终端上显示进度，使代码可视化进度加快
# 模拟浏览器访问
Headers = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3741.400 QQBrowser/10.5.3863.400'
# 题目数据
subjects = []
# 表头
csvHeaders = ['题号', '难度', '标题', '通过率', '通过数/总提交数']



# 爬取题目
print('题目信息爬取中：\n')
for pages in tqdm(range(1, 11 + 1)):

    r = requests.get(f'http://www.51mxd.cn/problemset.php-page={pages}.htm', Headers)

    r.raise_for_status()

    r.encoding = 'utf-8'

    soup = BeautifulSoup(r.text, 'html.parser')

    td = soup.find_all('td')#讲所有含TD的项提取出来
    subject = []
    for t in td:
        if t.string is not None:
            #利用string方法获取其中的内容
            subject.append(t.string)
            if len(subject) == 5:
                subjects.append(subject)
                subject = []

with open('D:\\net_com\\nylgoj.csv', 'w', newline='') as file:
    fileWriter = csv.writer(file)
    fileWriter.writerow(csvHeaders)
    fileWriter.writerows(subjects)

print('\n题目信息爬取完成！！！')


# In[5]:


# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 14:39:03 2021

@author: 86199
"""
import requests
from bs4 import BeautifulSoup
import csv
from tqdm import tqdm
import urllib.request, urllib.error  # 制定URL 获取网页数据

# 所有新闻
subjects = []

# 模拟浏览器访问
Headers = {  # 模拟浏览器头部信息
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 Edg/95.0.1020.53"
}

# 表头
csvHeaders = ['时间', '标题']


print('信息爬取中：\n')
for pages in tqdm(range(1, 65 + 1)):
    # 发出请求
    request = urllib.request.Request(f'http://news.cqjtu.edu.cn/xxtz/{pages}.htm', headers=Headers)
    html = ""
    # 如果请求成功则获取网页内容
    try:
        response = urllib.request.urlopen(request)
        html = response.read().decode("utf-8")
    except urllib.error.URLError as e:
        if hasattr(e, "code"):
            print(e.code)
        if hasattr(e, "reason"):
            print(e.reason)
    # 解析网页
    soup = BeautifulSoup(html, 'html.parser')

    # 存放一条新闻
    subject = []
    # 查找所有li标签
    li = soup.find_all('li')
    for l in li:
        # 查找满足条件的div标签
        if l.find_all('div',class_="time") is not None and l.find_all('div',class_="right-title") is not None:
            # 时间
            for time in l.find_all('div',class_="time"):
                subject.append(time.string)
            # 标题
            for title in l.find_all('div',class_="right-title"):
                for t in title.find_all('a',target="_blank"):
                    subject.append(t.string)
            if subject:
                print(subject)
                subjects.append(subject)
        subject = []

# 保存数据
with open('D:\\net_com\\test.csv', 'w', newline='',encoding='utf-8') as file:
    fileWriter = csv.writer(file)
    fileWriter.writerow(csvHeaders)
    fileWriter.writerows(subjects)

print('\n信息爬取完成！！！')


# In[ ]:




